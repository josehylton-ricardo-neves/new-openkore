package priestTurnUndead;

use strict;
use warnings;

use Time::HiRes qw(time);
use Plugins;
use Globals;
use Log qw(message warning);
use AI;
use Commands;
use Network;
use Skill;
use Actor;

my $PLUGIN = 'priestTurnUndead';

Plugins::register(
    $PLUGIN,
    'Configura Turn Undead em Evil Druid/Wraith e teleporta apos N usos sem matar',
    \&onUnload
);

my $hooks = Plugins::addHooks(
    ['AI_post', \&onAI],
);

my $commands = Commands::register(
    ['ptu', 'Controle do priestTurnUndead', \&cmdTU]
);

my $applied = 0;
my $slot;
my %savedGlobal;
my %savedSlot;
my %teleported;
my $lastTick = 0;

sub cfg {
    my ($key, $default) = @_;
    return $default if !exists $config{$key};
    return $default if !defined $config{$key};
    return $default if $config{$key} eq '';
    return $config{$key};
}

sub enabled {
    my ($key, $default) = @_;
    return cfg($key, $default) ? 1 : 0;
}

sub logInfo {
    my ($msg) = @_;
    message "[priestTurnUndead] $msg\n", 'info';
}

sub saveKey {
    my ($store, $key) = @_;
    return if exists $store->{$key};

    $store->{$key} = {
        exists => exists $config{$key},
        value  => (exists $config{$key} ? $config{$key} : undef),
    };
}

sub restoreStore {
    my ($store) = @_;

    foreach my $key (keys %$store) {
        if ($store->{$key}{exists}) {
            $config{$key} = $store->{$key}{value};
        } else {
            delete $config{$key};
        }
    }

    %$store = ();
}

sub firstFreeSlot {
    my $i = 0;
    $i++ while exists $config{"attackSkillSlot_$i"};
    return $i;
}

sub listMatches {
    my ($list, $name, $nameID) = @_;

    foreach my $entry (split /\s*,\s*/, ($list || '')) {
        next if $entry eq '';
        return 1 if defined $name && lc($entry) eq lc($name);
        return 1 if defined $nameID && $entry =~ /^\d+$/ && $entry == $nameID;
    }

    return 0;
}

sub applyConfig {
    return unless enabled('priestTurnUndead_enabled', 1);
    return if $ai_v{priestPluginLock};

    if (!$applied) {
        $slot = cfg('priestTurnUndead_slot', '');
        $slot = firstFreeSlot() if $slot eq '';

        foreach my $key (qw(
            attackAuto attackUseWeapon
            attackDistanceAuto attackDistance attackMaxDistance
            runFromTarget runFromTarget_inAdvance runFromTarget_dist
            runFromTarget_minStep runFromTarget_maxPathDistance
        )) {
            saveKey(\%savedGlobal, $key);
        }

        saveKey(\%savedSlot, "attackSkillSlot_$slot");

        for my $suffix (qw(
            lvl dist maxDist maxCastTime minCastTime
            monsters maxAttempts maxUses isSelfSkill sp disabled
        )) {
            saveKey(\%savedSlot, "attackSkillSlot_${slot}_$suffix");
        }

        $applied = 1;
        logInfo("Usando attackSkillSlot_$slot.");
    }

    my $dist = cfg('priestTurnUndead_distance', 5);

    $config{attackAuto} = cfg('priestTurnUndead_attackAuto', 2);
    $config{attackUseWeapon} = enabled('priestTurnUndead_useWeapon', 0);
    $config{attackDistanceAuto} = 0;
    $config{attackDistance} = $dist;
    $config{attackMaxDistance} = $dist;

    $config{runFromTarget} = enabled('priestTurnUndead_kite', 1);
    $config{runFromTarget_inAdvance} =
        enabled('priestTurnUndead_kiteInAdvance', 0);
    $config{runFromTarget_dist} =
        cfg('priestTurnUndead_kiteDistance', $dist);
    $config{runFromTarget_minStep} =
        cfg('priestTurnUndead_kiteMinStep', 3);
    $config{runFromTarget_maxPathDistance} =
        cfg('priestTurnUndead_kiteMaxPath', 13);

    $config{"attackSkillSlot_$slot"} =
        cfg('priestTurnUndead_skill', 'Turn Undead');
    $config{"attackSkillSlot_${slot}_lvl"} =
        cfg('priestTurnUndead_level', 10);
    $config{"attackSkillSlot_${slot}_dist"} = $dist;
    $config{"attackSkillSlot_${slot}_maxDist"} = $dist;
    $config{"attackSkillSlot_${slot}_maxCastTime"} =
        cfg('priestTurnUndead_maxCastTime', 0);
    $config{"attackSkillSlot_${slot}_minCastTime"} =
        cfg('priestTurnUndead_minCastTime', 0);
    $config{"attackSkillSlot_${slot}_monsters"} =
        cfg('priestTurnUndead_monsters', 'Evil Druid,Wraith');
    $config{"attackSkillSlot_${slot}_maxAttempts"} =
        cfg('priestTurnUndead_maxAttempts', 0);
    $config{"attackSkillSlot_${slot}_maxUses"} =
        cfg('priestTurnUndead_maxUses', 2);
    $config{"attackSkillSlot_${slot}_isSelfSkill"} = 0;
    $config{"attackSkillSlot_${slot}_sp"} =
        cfg('priestTurnUndead_sp', '> 20');
    $config{"attackSkillSlot_${slot}_disabled"} = 0;
}

sub restoreConfig {
    return unless $applied;

    restoreStore(\%savedSlot);
    restoreStore(\%savedGlobal);

    undef $slot;
    $applied = 0;
    %teleported = ();

    logInfo('Configuracao de TU restaurada/removida.');
}

sub processTarget {
    return unless $applied;
    return if $ai_v{priestPluginLock};
    return unless AI::action() && AI::action() eq 'attack';

    my $args = AI::args();
    return unless $args && defined $args->{ID};

    my $ID = $args->{ID};
    my $target = Actor::get($ID);
    return unless $target;
    return if $target->{dead};

    my $monsterList =
        cfg('priestTurnUndead_monsters', 'Evil Druid,Wraith');

    return unless listMatches(
        $monsterList,
        $target->{name},
        $target->{nameID}
    );

    my $skillName =
        cfg('priestTurnUndead_skill', 'Turn Undead');

    my $skill = Skill->new(auto => $skillName);
    return unless $skill;

    my $handle = $skill->getHandle();
    my $uses = $target->{skillUses}{$handle} || 0;
    my $maxUses = cfg('priestTurnUndead_maxUses', 2);

    return unless $maxUses > 0;
    return unless $uses >= $maxUses;
    return if $teleported{$ID};

    $teleported{$ID} = time;

    logInfo("$target->{name} sobreviveu a $uses uso(s) de $skillName. Teleport Lv.1.");

    AI::clear(qw(attack route mapRoute move));
    ai_useTeleport(1);
}

sub cleanupOldTargets {
    my $now = time;
    for my $ID (keys %teleported) {
        delete $teleported{$ID} if ($now - $teleported{$ID}) > 60;
    }
}

sub onAI {
    return unless $char && $field && $net;
    return unless $net->getState() == Network::IN_GAME;

    my $now = time;
    return if ($now - $lastTick) < 0.20;
    $lastTick = $now;

    if (!enabled('priestTurnUndead_enabled', 1)) {
        restoreConfig() if $applied;
        return;
    }

    # Se outro plugin (Rescue/Kafra) estiver executando uma rotina exclusiva,
    # TU nao mexe na AI ate o lock ser liberado.
    return if $ai_v{priestPluginLock};

    applyConfig();
    processTarget();
    cleanupOldTargets();
}

sub cmdTU {
    my ($cmd, $args) = @_;
    $args //= '';

    if ($args eq '' || $args eq 'status') {
        message "------ priestTurnUndead ------\n";
        message "enabled: " . enabled('priestTurnUndead_enabled', 1) . "\n";
        message "applied: " . ($applied ? 1 : 0) . "\n";
        message "slot: " . (defined $slot ? $slot : '-') . "\n";
        message "monsters: "
            . cfg('priestTurnUndead_monsters', 'Evil Druid,Wraith') . "\n";
        message "maxUses: "
            . cfg('priestTurnUndead_maxUses', 2) . "\n";
        message "lock: " . ($ai_v{priestPluginLock} || '-') . "\n";
        message "------------------------------\n";
        return;
    }

    if ($args eq 'apply') {
        applyConfig();
        return;
    }

    if ($args eq 'restore') {
        restoreConfig();
        return;
    }

    message "Uso: ptu status | ptu apply | ptu restore\n";
}

sub onUnload {
    restoreConfig();
    Plugins::delHooks($hooks);
    Commands::unregister($commands);
}

1;
