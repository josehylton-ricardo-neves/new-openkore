PRIEST PLUGINS SEPARADOS

Estrutura recomendada:

plugins/
  priestWarpKafra/
    priestWarpKafra.pl

  priestRescue/
    priestRescue.pl

  priestTurnUndead/
    priestTurnUndead.pl


1) priestWarpKafra
   - peso >= limite configurado
   - Teleport Lv.2
   - volta ao saveMap
   - autostorage
   - Warp Portal
   - entra no portal
   - volta ao mapa configurado

   Comandos:
     pwk status
     pwk run
     pwk reset


2) priestRescue
   - detecta membro morto da party
   - SOMENTE se estiver no mesmo mapa
   - Teleport Lv.1 enquanto estiver longe
   - anda quando cair perto
   - usa Resurrection
   - libera a rotina normal

   Comandos:
     prescue status
     prescue run
     prescue reset


3) priestTurnUndead
   - configura a caça de Evil Druid/Wraith
   - usa Turn Undead no alcance configurado
   - usa maxUses configurado
   - se o monstro sobreviver ao numero de TUs:
     Teleport Lv.1

   Comandos:
     ptu status
     ptu apply
     ptu restore


Os plugins usam ai_v{priestPluginLock} para que Rescue/Kafra
possam pausar temporariamente a rotina do Turn Undead quando
mais de um estiver carregado.

IMPORTANTE:
- Ajuste Kafra X Y.
- Rode "warp list" e use o nome exato da coluna Map em
  priestWarpKafra_warpMap.
- Mantenha Blue Gemstone suficiente no inventario.
- O personagem que deve ser ressuscitado deve usar dcOnDeath -1.
