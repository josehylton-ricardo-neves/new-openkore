package priestWarpKafra;

use strict;
use warnings;

use Time::HiRes qw(time);
use Plugins;
use Globals;
use Log qw(message warning error);
use AI;
use Commands;
use Network;
use Skill;

my $PLUGIN = 'priestWarpKafra';

Plugins::register(
    $PLUGIN,
    'Peso -> Teleport Lv.2 -> Kafra -> Warp Portal -> mapa de retorno',
    \&onUnload
);

my $hooks = Plugins::addHooks(
    ['AI_post',                   \&onAI],
    ['packet/warp_portal_list',   \&onWarpPortalList],
    ['AI_storage_auto_completed', \&onStorageCompleted],
);

my $commands = Commands::register(
    ['pwk', 'Controle do priestWarpKafra', \&cmdPWK]
);

my $mode = 'idle';
my $stateTime = time;
my $lastTick = 0;
my $lastCycle = 0;

my ($warpX, $warpY);
my $warpTries = 0;

my %saved;
my $paused = 0;

sub cfg {
    my ($key, $default) = @_;
    return $default if !exists $config{$key};
    return $default if !defined $config{$key};
    return $default if $config{$key} eq '';
    return $config{$key};
}

sub enabled {
    my ($key, $default) = @_;
    return cfg($key, $default) ? 1 : 0;
}

sub normalizeMap {
    my ($map) = @_;
    return '' unless defined $map;
    $map =~ s/^\s+|\s+$//g;
    $map =~ s/\.gat$//i;
    return $map;
}

sub currentMap {
    return '' unless $field;
    return normalizeMap($field->baseName);
}

sub saveMap {
    my $map = cfg('priestWarpKafra_saveMap', '');
    $map = $config{saveMap} if $map eq '';
    return normalizeMap($map);
}

sub warpMap {
    return normalizeMap(cfg('priestWarpKafra_warpMap', ''));
}

sub weightPercent {
    return 0 unless $char;
    return $char->{percent_weight} if defined $char->{percent_weight};
    return 0 unless $char->{weight_max};
    return ($char->{weight} * 100) / $char->{weight_max};
}

sub logInfo {
    my ($msg) = @_;
    message "[priestWarpKafra] $msg\n", 'info';
}

sub logOK {
    my ($msg) = @_;
    message "[priestWarpKafra] $msg\n", 'success';
}

sub acquireLock {
    return 1 if (($ai_v{priestPluginLock} || '') eq $PLUGIN);
    return 0 if $ai_v{priestPluginLock};
    $ai_v{priestPluginLock} = $PLUGIN;
    return 1;
}

sub releaseLock {
    delete $ai_v{priestPluginLock}
        if (($ai_v{priestPluginLock} || '') eq $PLUGIN);
}

sub saveKey {
    my ($key) = @_;
    return if exists $saved{$key};

    $saved{$key} = {
        exists => exists $config{$key},
        value  => (exists $config{$key} ? $config{$key} : undef),
    };
}

sub pauseRoutine {
    return if $paused;

    foreach my $key (qw(attackAuto route_randomWalk lockMap)) {
        saveKey($key);
    }

    $paused = 1;
    $config{attackAuto} = -1;
    $config{route_randomWalk} = 0;
    $config{lockMap} = '';

    # Nao apagamos skill_use para nao cancelar buff/skill manual.
    AI::clear(qw(attack route mapRoute move items_take items_gather take));
}

sub restoreRoutine {
    return unless $paused;

    foreach my $key (keys %saved) {
        if ($saved{$key}{exists}) {
            $config{$key} = $saved{$key}{value};
        } else {
            delete $config{$key};
        }
    }

    %saved = ();
    $paused = 0;
}

sub setMode {
    my ($newMode) = @_;
    $mode = $newMode;
    $stateTime = time;
}

sub resetCycle {
    my ($why) = @_;

    warning "[priestWarpKafra] $why\n" if defined $why && $why ne '';

    AI::clear(qw(route mapRoute move teleport));
    restoreRoutine();
    releaseLock();

    undef $warpX;
    undef $warpY;
    $warpTries = 0;

    setMode('idle');
}

sub hasBlueGemstone {
    return 0 unless $char && $char->inventory && $char->inventory->isReady();

    for my $item (@{$char->inventory}) {
        next unless $item;
        next unless ($item->{amount} || 0) > 0;

        return 1 if ($item->{nameID} || 0) == 717;
        return 1 if lc($item->{name} || '') eq 'blue gemstone';
    }

    return 0;
}

sub findWarpCell {
    return unless $char && $field;

    my $p = $char->{pos_to} || $char->{pos};
    return unless $p;

    for my $radius (1, 2) {
        for my $dx (-$radius .. $radius) {
            for my $dy (-$radius .. $radius) {
                next if $dx == 0 && $dy == 0;
                next unless abs($dx) == $radius || abs($dy) == $radius;

                my $x = $p->{x} + $dx;
                my $y = $p->{y} + $dy;

                next if $x < 0 || $y < 0;
                next unless $field->isWalkable($x, $y);

                return ($x, $y);
            }
        }
    }

    return;
}

sub startCycle {
    return unless acquireLock();

    my $save = saveMap();
    my $warp = warpMap();

    if ($save eq '') {
        releaseLock();
        error "[priestWarpKafra] Configure saveMap ou priestWarpKafra_saveMap.\n";
        return;
    }

    if ($warp eq '') {
        releaseLock();
        error "[priestWarpKafra] Configure priestWarpKafra_warpMap com o mapa mostrado por 'warp list'.\n";
        return;
    }

    pauseRoutine();

    logOK(sprintf(
        "Peso %.1f%%. Iniciando Teleport Lv.2 -> %s -> Kafra -> Warp -> %s.",
        weightPercent(), $save, $warp
    ));

    if ($char->{sitting}) {
        stand();
        setMode('wait_stand_tp');
    } else {
        startTeleport2();
    }
}

sub startTeleport2 {
    AI::clear(qw(attack route mapRoute move));
    logInfo("Usando Teleport Lv.2 para o save point " . saveMap() . ".");

    # O OpenKore atual trata a lista do Teleport Lv.2 enquanto
    # a acao 'teleport' permanece na fila e envia saveMap automaticamente.
    ai_useTeleport(2);
    setMode('wait_save');
}

sub startStorage {
    logInfo('Iniciando autostorage na Kafra configurada.');
    Commands::run('autostorage');
    setMode('storage');
}

sub castWarpPortal {
    unless (hasBlueGemstone()) {
        resetCycle('Sem Blue Gemstone para abrir Warp Portal.');
        return;
    }

    my ($x, $y) = findWarpCell();
    unless (defined $x && defined $y) {
        resetCycle('Nao encontrei uma celula caminhavel para abrir Warp Portal.');
        return;
    }

    $warpX = $x;
    $warpY = $y;
    $warpTries++;

    my $skillName = cfg('priestWarpKafra_warpSkill', 'Warp Portal');
    my $skill = Skill->new(auto => $skillName);

    unless ($skill) {
        resetCycle("Nao encontrei a skill '$skillName'.");
        return;
    }

    my $level = cfg('priestWarpKafra_warpLevel', 4);

    logInfo("Abrindo $skillName Lv.$level em $warpX,$warpY.");

    ai_skillUse(
        $skill->getHandle(),
        $level,
        cfg('priestWarpKafra_warpMaxCastTime', 0),
        cfg('priestWarpKafra_warpMinCastTime', 0),
        $warpX,
        $warpY
    );

    setMode('wait_warp_list');
}

sub enterPortal {
    return unless defined $warpX && defined $warpY;

    AI::clear(qw(route mapRoute move));

    logInfo("Andando para dentro do Warp Portal em $warpX,$warpY.");

    ai_route(
        currentMap(),
        $warpX,
        $warpY,
        attackOnRoute => 0,
        noSitAuto => 1,
        distFromGoal => 0,
    );

    setMode('enter_portal');
}

sub finishCycle {
    logOK("Cheguei em " . warpMap() . ". Rotina normal liberada.");

    $lastCycle = time;

    AI::clear(qw(route mapRoute move));
    restoreRoutine();
    releaseLock();

    undef $warpX;
    undef $warpY;
    $warpTries = 0;

    setMode('idle');
}

sub onWarpPortalList {
    my ($hook, $args) = @_;
    return unless $mode eq 'wait_warp_list';
    return unless $args && defined $args->{type};
    return unless $args->{type} == 27;

    my $map = warpMap();

    logInfo("Lista do Warp Portal recebida. Selecionando $map.");
    $messageSender->sendWarpTele(27, "$map.gat");

    setMode('wait_portal_ready');
}

sub onStorageCompleted {
    return unless $mode eq 'storage';

    logOK('Autostorage concluido.');
    setMode('before_warp');
}

sub processState {
    my $now = time;

    if ($mode eq 'wait_stand_tp') {
        startTeleport2() if !$char->{sitting} && !AI::inQueue('standing');
        return;
    }

    if ($mode eq 'wait_save') {
        if (currentMap() eq saveMap()) {
            logOK("Cheguei ao save point " . saveMap() . ".");
            setMode('before_storage');
            return;
        }

        if (($now - $stateTime) > cfg('priestWarpKafra_teleportTimeout', 15)) {
            resetCycle('Teleport Lv.2 nao chegou ao save point dentro do timeout.');
        }
        return;
    }

    if ($mode eq 'before_storage') {
        startStorage()
            if ($now - $stateTime) >= cfg('priestWarpKafra_beforeStorageDelay', 1);
        return;
    }

    if ($mode eq 'storage') {
        if (($now - $stateTime) > cfg('priestWarpKafra_storageTimeout', 180)) {
            resetCycle('Autostorage excedeu o timeout.');
        }
        return;
    }

    if ($mode eq 'before_warp') {
        return if ($now - $stateTime) < cfg('priestWarpKafra_beforeWarpDelay', 1);

        if ($char->{sitting}) {
            stand();
            setMode('wait_stand_warp');
        } else {
            castWarpPortal();
        }
        return;
    }

    if ($mode eq 'wait_stand_warp') {
        castWarpPortal() if !$char->{sitting} && !AI::inQueue('standing');
        return;
    }

    if ($mode eq 'wait_warp_list') {
        if (($now - $stateTime) > cfg('priestWarpKafra_warpListTimeout', 8)) {
            my $max = cfg('priestWarpKafra_warpMaxTries', 3);
            if ($warpTries < $max) {
                AI::clear('skill_use');
                castWarpPortal();
            } else {
                resetCycle('Warp Portal nao abriu a lista de destinos.');
            }
        }
        return;
    }

    if ($mode eq 'wait_portal_ready') {
        if (currentMap() eq warpMap()) {
            finishCycle();
            return;
        }

        enterPortal()
            if ($now - $stateTime) >= cfg('priestWarpKafra_portalDelay', 1.5);
        return;
    }

    if ($mode eq 'enter_portal') {
        if (currentMap() eq warpMap()) {
            finishCycle();
            return;
        }

        if (($now - $stateTime) > cfg('priestWarpKafra_enterTimeout', 15)) {
            # Tenta pisar novamente no ponto do portal.
            setMode('wait_portal_ready');
        }
        return;
    }
}

sub onAI {
    return unless enabled('priestWarpKafra_enabled', 1);
    return unless $char && $field && $net;
    return unless $net->getState() == Network::IN_GAME;

    my $now = time;
    return if ($now - $lastTick) < 0.20;
    $lastTick = $now;

    if ($mode ne 'idle') {
        processState();
        return;
    }

    return if $ai_v{priestPluginLock};

    my $limit = cfg('priestWarpKafra_weightPercent', 50);
    my $cooldown = cfg('priestWarpKafra_cycleCooldown', 30);

    if (weightPercent() >= $limit && ($now - $lastCycle) >= $cooldown) {
        startCycle();
    }
}

sub cmdPWK {
    my ($cmd, $args) = @_;
    $args //= '';

    if ($args eq '' || $args eq 'status') {
        message "------ priestWarpKafra ------\n";
        message "mode: $mode\n";
        message "peso: " . sprintf('%.1f', weightPercent()) . "%\n";
        message "limite: " . cfg('priestWarpKafra_weightPercent', 50) . "%\n";
        message "saveMap: " . saveMap() . "\n";
        message "warpMap: " . warpMap() . "\n";
        message "lock: " . ($ai_v{priestPluginLock} || '-') . "\n";
        message "-----------------------------\n";
        return;
    }

    if ($args eq 'run') {
        if ($mode ne 'idle') {
            warning "[priestWarpKafra] Rotina ja esta em andamento: $mode\n";
            return;
        }
        startCycle();
        return;
    }

    if ($args eq 'reset') {
        resetCycle('Reset manual.');
        return;
    }

    message "Uso: pwk status | pwk run | pwk reset\n";
}

sub onUnload {
    AI::clear(qw(route mapRoute move teleport));
    restoreRoutine();
    releaseLock();
    Plugins::delHooks($hooks);
    Commands::unregister($commands);
}

1;
