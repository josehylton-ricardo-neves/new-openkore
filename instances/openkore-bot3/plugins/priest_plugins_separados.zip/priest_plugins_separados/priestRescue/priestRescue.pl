package priestRescue;

use strict;
use warnings;

use Time::HiRes qw(time);
use Plugins;
use Globals;
use Log qw(message warning error);
use AI;
use Commands;
use Network;
use Skill;

my $PLUGIN = 'priestRescue';

Plugins::register(
    $PLUGIN,
    'Resgata membro morto da party no mesmo mapa usando Teleport Lv.1 + Resurrection',
    \&onUnload
);

my $hooks = Plugins::addHooks(
    ['AI_post', \&onAI],
);

my $commands = Commands::register(
    ['prescue', 'Controle do priestRescue', \&cmdRescue]
);

my $active = 0;
my $rescueID;
my $lastTick = 0;
my $lastTeleport = 0;
my $lastRoute = 0;
my $lastResurrection = 0;

my %saved;
my $paused = 0;

sub cfg {
    my ($key, $default) = @_;
    return $default if !exists $config{$key};
    return $default if !defined $config{$key};
    return $default if $config{$key} eq '';
    return $config{$key};
}

sub enabled {
    my ($key, $default) = @_;
    return cfg($key, $default) ? 1 : 0;
}

sub normalizeMap {
    my ($map) = @_;
    return '' unless defined $map;
    $map =~ s/^\s+|\s+$//g;
    $map =~ s/\.gat$//i;
    return $map;
}

sub currentMap {
    return '' unless $field;
    return normalizeMap($field->baseName);
}

sub blockDist {
    my ($a, $b) = @_;
    return 99999 unless $a && $b;
    return 99999 unless defined $a->{x} && defined $a->{y};
    return 99999 unless defined $b->{x} && defined $b->{y};

    my $dx = abs($a->{x} - $b->{x});
    my $dy = abs($a->{y} - $b->{y});
    return $dx > $dy ? $dx : $dy;
}

sub targetAllowed {
    my ($name) = @_;
    my $targets = cfg('priestRescue_targets', 'all');

    foreach my $entry (split /\s*,\s*/, $targets) {
        next if $entry eq '';
        return 1 if lc($entry) eq 'all';
        return 1 if defined $name && lc($entry) eq lc($name);
    }

    return 0;
}

sub logInfo {
    my ($msg) = @_;
    message "[priestRescue] $msg\n", 'info';
}

sub logOK {
    my ($msg) = @_;
    message "[priestRescue] $msg\n", 'success';
}

sub acquireLock {
    return 1 if (($ai_v{priestPluginLock} || '') eq $PLUGIN);
    return 0 if $ai_v{priestPluginLock};
    $ai_v{priestPluginLock} = $PLUGIN;
    return 1;
}

sub releaseLock {
    delete $ai_v{priestPluginLock}
        if (($ai_v{priestPluginLock} || '') eq $PLUGIN);
}

sub saveKey {
    my ($key) = @_;
    return if exists $saved{$key};

    $saved{$key} = {
        exists => exists $config{$key},
        value  => (exists $config{$key} ? $config{$key} : undef),
    };
}

sub pauseRoutine {
    return if $paused;

    foreach my $key (qw(attackAuto route_randomWalk lockMap)) {
        saveKey($key);
    }

    $paused = 1;
    $config{attackAuto} = -1;
    $config{route_randomWalk} = 0;
    $config{lockMap} = '';

    # Nao limpa skill_use: evita cancelar buff/cast manual.
    AI::clear(qw(attack route mapRoute move items_take items_gather take));
}

sub restoreRoutine {
    return unless $paused;

    foreach my $key (keys %saved) {
        if ($saved{$key}{exists}) {
            $config{$key} = $saved{$key}{value};
        } else {
            delete $config{$key};
        }
    }

    %saved = ();
    $paused = 0;
}

sub memberMap {
    my ($member) = @_;
    return '' unless $member;
    return normalizeMap($member->{map});
}

sub findDeadMember {
    return unless $char && $char->{party} && $char->{party}{users};

    my $map = currentMap();

    for my $ID (keys %{$char->{party}{users}}) {
        next if defined $accountID && $ID eq $accountID;

        my $member = $char->{party}{users}{$ID};
        next unless $member;
        next unless $member->{dead};
        next if exists $member->{online} && !$member->{online};
        next unless targetAllowed($member->{name});

        # Regra pedida: SO resgata se estiver no mesmo mapa.
        next unless memberMap($member) eq $map;

        next unless $member->{pos};
        next unless defined $member->{pos}{x} && defined $member->{pos}{y};
        next if $member->{pos}{x} >= 65535 || $member->{pos}{y} >= 65535;

        return ($ID, $member);
    }

    return;
}

sub startRescue {
    my ($ID, $member) = @_;
    return unless acquireLock();

    pauseRoutine();

    $active = 1;
    $rescueID = $ID;
    $lastTeleport = 0;
    $lastRoute = 0;
    $lastResurrection = 0;

    logOK("$member->{name} morreu em "
        . currentMap() . " $member->{pos}{x},$member->{pos}{y}. Iniciando resgate.");
}

sub finishRescue {
    my ($member) = @_;
    my $name = $member && $member->{name} ? $member->{name} : 'aliado';

    logOK("$name esta vivo novamente. Liberando a rotina normal.");

    AI::clear(qw(route mapRoute move));
    restoreRoutine();
    releaseLock();

    $active = 0;
    undef $rescueID;
}

sub cancelRescue {
    my ($why) = @_;
    warning "[priestRescue] $why\n" if $why;

    AI::clear(qw(route mapRoute move teleport));
    restoreRoutine();
    releaseLock();

    $active = 0;
    undef $rescueID;
}

sub processRescue {
    return unless $active && defined $rescueID;
    return unless $char->{party} && $char->{party}{users};

    my $member = $char->{party}{users}{$rescueID};

    unless ($member) {
        cancelRescue('O membro saiu da party.');
        return;
    }

    unless ($member->{dead}) {
        finishRescue($member);
        return;
    }

    unless (memberMap($member) eq currentMap()) {
        cancelRescue("$member->{name} nao esta mais no mesmo mapa.");
        return;
    }

    my $corpse = $member->{pos};
    unless ($corpse && defined $corpse->{x} && defined $corpse->{y}) {
        return;
    }

    my $me = $char->{pos_to} || $char->{pos};
    my $dist = blockDist($me, $corpse);

    my $teleUntil = cfg('priestRescue_teleportUntilDistance', 30);
    my $skillRange = cfg('priestRescue_skillRange', 8);
    my $teleCooldown = cfg('priestRescue_teleportCooldown', 1.2);

    # Muito longe: Teleport Lv.1 ate cair perto.
    if ($dist > $teleUntil) {
        return if AI::inQueue('teleport');

        if ((time - $lastTeleport) >= $teleCooldown) {
            AI::clear(qw(route mapRoute move));
            logInfo("Corpo a $dist celulas. Usando Teleport Lv.1.");
            ai_useTeleport(1);
            $lastTeleport = time;
        }
        return;
    }

    # Perto o bastante para parar de teleportar, mas ainda fora do range.
    if ($dist > $skillRange) {
        if (!AI::inQueue('route', 'mapRoute', 'move')
            && (time - $lastRoute) >= 1) {

            logInfo("Cai perto do corpo (dist $dist). Andando ate alcance.");

            ai_route(
                currentMap(),
                $corpse->{x},
                $corpse->{y},
                attackOnRoute => 0,
                noSitAuto => 1,
                distFromGoal => ($skillRange > 1 ? $skillRange - 1 : 1),
            );

            $lastRoute = time;
        }
        return;
    }

    # Se a party deu coordenada mas o corpo ainda nao apareceu na tela,
    # aproxima mais antes de tentar castar.
    my $visible = $playersList ? $playersList->getByID($rescueID) : undef;
    if (!$visible && $dist > 2) {
        if (!AI::inQueue('route', 'mapRoute', 'move')
            && (time - $lastRoute) >= 1) {

            logInfo("Corpo ainda nao visivel. Aproximando mais.");

            ai_route(
                currentMap(),
                $corpse->{x},
                $corpse->{y},
                attackOnRoute => 0,
                noSitAuto => 1,
                distFromGoal => 2,
            );

            $lastRoute = time;
        }
        return;
    }

    return if AI::inQueue('skill_use');
    return if (time - $lastResurrection)
        < cfg('priestRescue_resurrectionCooldown', 2);

    my $skillName = cfg('priestRescue_skill', 'Resurrection');
    my $skill = Skill->new(auto => $skillName);

    unless ($skill) {
        cancelRescue("Nao encontrei a skill '$skillName'.");
        return;
    }

    my $level = cfg('priestRescue_level', 4);

    logInfo("Usando $skillName Lv.$level em $member->{name}.");

    ai_skillUse(
        $skill->getHandle(),
        $level,
        cfg('priestRescue_maxCastTime', 0),
        cfg('priestRescue_minCastTime', 0),
        $rescueID
    );

    $lastResurrection = time;
}

sub onAI {
    return unless enabled('priestRescue_enabled', 1);
    return unless $char && $field && $net;
    return unless $net->getState() == Network::IN_GAME;

    my $now = time;
    return if ($now - $lastTick) < 0.20;
    $lastTick = $now;

    if ($active) {
        processRescue();
        return;
    }

    return if $ai_v{priestPluginLock};

    my ($ID, $member) = findDeadMember();
    startRescue($ID, $member) if defined $ID;
}

sub cmdRescue {
    my ($cmd, $args) = @_;
    $args //= '';

    if ($args eq '' || $args eq 'status') {
        message "-------- priestRescue --------\n";
        message "ativo: " . ($active ? 1 : 0) . "\n";
        message "mapa: " . currentMap() . "\n";
        message "targets: " . cfg('priestRescue_targets', 'all') . "\n";
        message "lock: " . ($ai_v{priestPluginLock} || '-') . "\n";
        message "------------------------------\n";
        return;
    }

    if ($args eq 'run') {
        if ($active) {
            warning "[priestRescue] Ja existe um resgate em andamento.\n";
            return;
        }

        my ($ID, $member) = findDeadMember();
        if (defined $ID) {
            startRescue($ID, $member);
        } else {
            warning "[priestRescue] Nenhum membro configurado morto no mesmo mapa.\n";
        }
        return;
    }

    if ($args eq 'reset') {
        cancelRescue('Reset manual.');
        return;
    }

    message "Uso: prescue status | prescue run | prescue reset\n";
}

sub onUnload {
    cancelRescue('');
    Plugins::delHooks($hooks);
    Commands::unregister($commands);
}

1;
